151 sample RAG-aware SFT RESEARCH package.
136 train + 15 val, 17 doctor-red cases (14 answers AI-edited, 3 histories normalized).
All 151 physician VERDICT cells blank: this package is technically trainable but NOT certified/approved by a physician.
Context contains 3 review excerpt snippets, max 700 chars each; not original full RAG chunks.
Extract to repo root; current config configs/training/sft_qwen3_8b_v3.yaml points at these paths.
Run preflight before GPU training; DO NOT deploy model as clinical advice without evaluation.
